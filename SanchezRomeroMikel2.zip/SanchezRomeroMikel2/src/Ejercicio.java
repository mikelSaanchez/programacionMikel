import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejercicio {
	public static int leerInt() throws NumberFormatException, IOException {
		BufferedReader leer = new BufferedReader(new InputStreamReader(System.in));
		int num = Integer.parseInt(leer.readLine());
		return num;
	}
	public static double leerDouble() throws NumberFormatException, IOException {
		BufferedReader leer = new BufferedReader(new InputStreamReader(System.in));
		double num = Double.parseDouble(leer.readLine());
		return num;
	}
	public static String leerString() throws IOException {
		BufferedReader leer = new BufferedReader(new InputStreamReader(System.in));
		String palabra = leer.readLine();
		return palabra;
	}
	public static char leerChar() throws IOException {
		BufferedReader leer = new BufferedReader(new InputStreamReader(System.in));
		char palabra = leer.readLine().toUpperCase().charAt(0);
		return palabra;
	}
	
	public static void main(String[] args) throws NumberFormatException, IOException {
			boolean salir = false;
			do {
				try {
			System.out.println("=== BIBLIOTECA Calasanz Games ===");
			System.out.println();
			System.out.println("1. Gestión de Usuarios");
			System.out.println("2. Catálogo de Juegos");
			System.out.println("3. Sistema de Valoraciones");
			System.out.println("4. Estadísticas y Reportes");
			System.out.println("5. Calculadora de Descuentos");
			System.out.println("6. Salir");
			System.out.println();
			System.out.print("Elige una opción: ");
			int opcion = leerInt();
			switch (opcion) {
			case 1:
				menu1();
			break;
			case 2:
				menu2();
			break;
			case 3:
				menu3();
			break;
			case 4:
				menu4();
			break;
			case 5:
				menu5();
			break;
			case 6:
			salir = true;
			System.out.println("¡Hasta luego!");
			break;
			default:
			System.out.println("Opción no válida");
			}
			}catch(IOException  | NumberFormatException e) {
				System.out.println("Introduce numero, no letras.");
			}
			}while(!salir);
	}
	
	public static void menu1() throws NumberFormatException, IOException {
		boolean salir = false;
		do {
			try {
			System.out.println("--- GESTIÓN DE USUARIOS ---");
			System.out.println("1. Crear nuevo usuario");
			System.out.println("2. Calcular edad del usuario");
			System.out.println("3. Volver al menú principal");
			int opcion = leerInt();
			switch(opcion) {
			case 1:
				menu1_1();
				break;
			case 2:
				menu1_2();
				break;
			case 3:
				salir = true;
				break;
			}
			}catch(IOException  | NumberFormatException e) {
				System.out.println("Introduce numero, no letras.");
			}
		}while(!salir);
	}
	public static void menu1_1() throws IOException {
		System.out.println("Nombre: ");
		String nombre = leerString();
		
		int añoNacimiento =añoNacimiento();
		
		String plataforma="";
		do {
		    System.out.println("Plataforma favorita (PC, PlayStation, Xbox, Nintendo): ");	
		    plataforma = leerString(); 
		    if (!plataforma.equalsIgnoreCase("PC") && !plataforma.equalsIgnoreCase("PlayStation") && !plataforma.equalsIgnoreCase("Xbox") && !plataforma.equalsIgnoreCase("Nintendo")) {
		        System.out.println("Opción no válida.");
		    }
		} while (!plataforma.equalsIgnoreCase("PC") && !plataforma.equalsIgnoreCase("PlayStation") && !plataforma.equalsIgnoreCase("Xbox") && !plataforma.equalsIgnoreCase("Nintendo"));
		System.out.println("¿Tiene suscripción premium? (S/N): ");
		char suscripcionPremium = leerChar();
		//ID usuario
		String nombreID = nombre.substring(0,3).toUpperCase();
		String ID = nombreID + "GAME"+añoNacimiento;
		System.out.println("ID Usuario: "+ID);
		System.out.println("Edad: "+edad(añoNacimiento));
		if(edad(añoNacimiento)<=17) {
			System.out.println("Tipo de usuario: Junior Game");
		}else if(edad(añoNacimiento)>18 && edad(añoNacimiento)<=30 ) {
			System.out.println("Tipo de usuario: Pro Gamer");
		}else {
			System.out.println("Tipo de usuario: Master Gamer.");
		}
		System.out.println("Plataforma favorita: "+plataforma);
		if(suscripcionPremium == 'S') {
			System.out.println("Premium: Si");
		}else {
			System.out.println("Premium: No");
		}
	}
	public static void menu1_2() throws IOException {
		int añoNacimiento =añoNacimiento();
		int edad = edad(añoNacimiento);
		System.out.println("Edad: "+edad);
		if(añoNacimiento>=1920 && añoNacimiento<=2025) {
			if(edad>=18) {
				System.out.println("Puede jugar a juegos con etiqueta: PEGI 18");
			}else if(edad>=16) {
				System.out.println("Puede jugar a juegos con etiqueta: PEGI 16");
			}else if(edad>=12) {
				System.out.println("Puede jugar a juegos con etiqueta: PEGI 12");
			}else if(edad>=7) {
				System.out.println("Puede jugar a juegos con etiqueta: PEGI 7");
				}else {
					System.out.println("Puede jugar a juegos con etiqueta: PEGI 3");
				}
		}else {
			System.out.println("No tiene la edad, para jugar a ningun juego.");
		}
	}
	public static int edad(int año) {
		int edad = 2025-año;
		return  edad;
	}
	public static int añoNacimiento() throws NumberFormatException, IOException {
		System.out.println("Año de nacimiento: ");
		int añoNacimiento = leerInt();
		return añoNacimiento;
	}
	public static void menu2()  {
		boolean salir = false;
		do {
			try {
			System.out.println("--- CATÁLOGO DE JUEGOS ---");
			System.out.println("1. Añadir juegos a la biblioteca");
			System.out.println("2. Calcular espacio total ocupado");
			System.out.println("3. Volver al menú principal");
			int opcion = leerInt();
			switch(opcion) {
			case 1:
				 menu2_1();
				break;
			case 2:
				 menu2_2();
				break;
			case 3:
				salir = true;
				break;
			}
			}catch(IOException  | NumberFormatException e) {
				System.out.println("Introduce numero, no letras.");
				}
		}while(!salir);
	}
	public static void menu2_1() {
		boolean todook = false;
		while(!todook) {
		try {
		System.out.println("¿Cuántos juegos quieres añadir?: ");
		int juegos = leerInt();
		int totalGB = 0;
		int totalPrecio = 0;
		for(int i = 0; i<juegos; i++) {
			System.out.println("Nombre del juego: ");
			String nombreJuego = leerString();
			System.out.println("Tamaño en GB de "+nombreJuego+" : ");
			int GB = leerInt();
			System.out.println("Precio de  "+nombreJuego+" : ");
			int precioJuego = leerInt();
			totalGB += GB;
			totalPrecio += precioJuego;
		}
		System.out.println("Total de juegos: "+juegos);
		System.out.println("Total Gastado: "+totalPrecio+"€");
		todook= true;
		}catch(IOException  | NumberFormatException e) {
			System.out.println("Introduce numero, no letras.");
		}
		}
	}
	public static void menu2_2(){
		boolean todook = false;
		while(!todook) {
		try {
			System.out.println("Memoria disponible en GB: ");
			int memoriaTotal = leerInt();
			System.out.println("¿Cuántos juegos vas a instalar?: ");
			int juegos = leerInt();
			int memoria = 0;
			int memoriaInical=0;
			for(int i = 0; i<juegos && memoriaTotal>=memoriaInical; i++) {
			System.out.println("Tamaño del juego "+(i+1)+" : ");
			memoria = leerInt();
			memoriaInical += memoria;
			if(memoriaTotal<=memoriaInical) {
				System.out.println("¡Memoria superada! No puedes instalar más juegos");
			}
		}
			System.out.println("Espacio total ocupado: "+memoriaInical);
			todook = true;
	}catch(IOException  | NumberFormatException e) {
		System.out.println("Introduce numero, no letras.");
			}
		}
	}
	public static void menu3()  {
		boolean todook = false;
		while(!todook) {
		try {
		System.out.println("Nombre del juego a valorar: ");
		String nombreJuego = leerString();
		System.out.println("¿Cuántos usuarios han valorado "+nombreJuego+"?: ");
		int usuariosValorado = leerInt();
		int notaMedia = 0;
		for(int i = 0; i<usuariosValorado;i++) {
			int valoracion = -1;
			while (valoracion < 0 || valoracion > 10) {
				System.out.println("Valoración del usuario "+(i+1)+" (0-10):");
				 valoracion = leerInt();
				 if (valoracion < 0 || valoracion > 10) {
						System.out.println("Nota no valida. Tiene que ser entre 1 y 10");
					}
				}
			notaMedia += valoracion;
	}
		double media = notaMedia/usuariosValorado;
		System.out.println("Nota media: "+media);
		if(media<=4.9) {
			System.out.println("Resumen: Decepcionante");
		}else if(media>5 && media<=6.9) {
			System.out.println("Resumen: Aceptable");
		}else if(media> 7 && media<=8.4) {
			System.out.println("Resumen: Bueno");
		}else if(media>8.5 && media<=9.4) {
			System.out.println("Resumen: Excelente");
		}else if (media>9.5){
			System.out.println("Resumen: Obra Maestra");
		}
		todook = true;
	}catch(IOException|NumberFormatException e) {
			System.out.println("Introduce numero, no letras.");
			}
		}
	}
	public static void menu4() {
		boolean salir = false;
		do {
			try {
			System.out.println("--- ESTADÍSTICAS Y REPORTES ---");
			System.out.println("1. Contador de juegos completados");
			System.out.println("2. Calcular horas totales de juego");
			System.out.println("3. Volver al menú principal");
			int opcion = leerInt();
			switch(opcion) {
			case 1:
				menu4_1();
				break;
			case 2:
				menu4_2();
				break;
			case 3:
				salir = true;
				break;
			}
			}catch(IOException  | NumberFormatException e) {
				System.out.println("Introduce numero, no letras.");
			}
		}while(!salir);
	}
	public static void menu4_1() throws NumberFormatException, IOException {
		try {
		System.out.println("Número de juegos completados este año: ");
		int juegoCompletado = leerInt();
		cuentaAtras(juegoCompletado);
		}catch(IOException|NumberFormatException e) {
			System.out.println("Introduce numero, no letras.");
			}
	}
	public static int cuentaAtras (int num) {
		if(num==1) {
			System.out.println("Has completado el juego número: " +num);
			return 1;
		}else {
			System.out.println("Has completado el juego número: " +num);
			return(cuentaAtras(num-1));
		}		
	}
	public static void menu4_2() {
		boolean todook = false;
		while(!todook) {
		try {
			System.out.println("¿Quieres introducir solo horas (H) o horas y minutos (HM)?: ");
			String opcion = leerString();
			if(opcion.equals("H")) {
			System.out.println("Horas:");
			int horas = leerInt();
			System.out.println("Total de horas jugadas:"+calcularHorasTotales(horas)); 
			todook = true;
			}else if (opcion.equals("HM")) {
				System.out.println("Horas:");
				int horas = leerInt();
				System.out.println("Minutos: ");
				int minutos=leerInt();
				calcularHorasTotales(horas,minutos);
				todook = true;
			}else {
			System.out.println("Caracter que no concuerda.");
			}
		} catch (IOException e) {
		}
		}
	}
	public static int calcularHorasTotales(int horas) {
		return horas ;
	}
	public static int calcularHorasTotales(int horas, int minutos) {
		int minutosTotales = minutos/60;
		int horasTotales = horas+minutosTotales;
		int minutos1= minutos%60;
		System.out.println("Total de horas jugadas:"+horasTotales+ ","+minutos1);
		return horasTotales;
	}
	public static void menu5() {
		boolean todook = false;
		while(!todook) {
		try {
			System.out.println("Introduce el precio del juego: ");
			int precio = leerInt();
			boolean todook1 = false;
			while(!todook1) {
			System.out.println("Introduce el porcentaje de descuento (0-100): ");
			int descuento = leerInt();
			if(descuento>0 && descuento<100) {
				System.out.println("Precio original: "+ precio);
				System.out.println("Precio final: "+ calcularDescuento(precio,descuento));
				double ahorro = precio - calcularDescuento(precio,descuento);
				System.out.println("Ahorro total: "+ahorro);
				todook1 = true;
			}else {
				System.out.println("Añade un porcentaje entre 0 y 100");
				}
			}
			todook= true;
		} catch (NumberFormatException | IOException e) {
			System.out.println("Introduce numero, no letras.");
		}
		}
	}
	public static double calcularDescuento(double precio, double descuento) {
		double descuentoFinal = descuento/100;
		double precioFinal = precio*descuentoFinal;
		double precioFinal1 =precio-precioFinal;
		if(precioFinal1>15) {
			return calcularDescuento(precioFinal1,5);
		}else {
		return precioFinal1;
		}
	}
}
