package ejercicioOpcional;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;

public class Oferta {
	
	private int id;
	private String nombre;
	private int cantidadOferta;
	private char resort;
	private boolean resort1;
	private String respuesta;
	
	
	public void pedirDatos( ArrayList<Oferta> ofertas) throws IOException {
		BufferedReader leer = new BufferedReader(new InputStreamReader(System.in));
		Random rand = new Random();
		int idGenerado = -1;
		do {
		 idGenerado = rand.nextInt(100)+1;
		}while(estaRepetido(ofertas, idGenerado));
		id = idGenerado;
		
		System.out.println("Introduce el nombre del postor:");
		 nombre = leer.readLine();
		System.out.println("Introduce la cantidad de la oferta (en millones de dólares):");
		cantidadOferta =Integer.parseInt(leer.readLine());
		System.out.println("¿Incluye resort de lujo? (true/false):");
		resort =leer.readLine().toUpperCase().charAt(0);	
		if(resort =='T') {
			resort1 = true;
		}else {
			resort1 = false;
		}
		System.out.println("respuesta de Dinamarca:");
		respuesta=leer.readLine();
	}
	
	private boolean estaRepetido(ArrayList<Oferta> ofertas,int idGenerado) {
		
		for(int i=0;i<(ofertas.size()-1);i++) {
			
			if(ofertas.get(i).getId() == id) {
				return true;
			}
		}
		return false;
	}
	public boolean ofertasBuenas() {
		
		if(cantidadOferta<=100) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean ofertasConResort(){
		if(resort1== true) {
			return true;
		}else {
			return false;
		}
	}
	public int getId() {
		return id;
	}
	public String getnombre() {
		return nombre;
	}
	
	public  String toString() {
		return "-- Oferta #"+id +"\n Postor: "+nombre+"\n Cantidad: "+cantidadOferta;
	}
	
}
