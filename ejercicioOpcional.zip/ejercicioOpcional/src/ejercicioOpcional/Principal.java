package ejercicioOpcional;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Principal {
	  public static void main(String[] args) throws IOException {
		  BufferedReader leer = new BufferedReader(new InputStreamReader(System.in));
			ArrayList<Oferta>ofertas = new ArrayList<Oferta>();
		  boolean salir = false;
			do {
				System.out.println("== GESTIÓN DE OFERTAS POR GROENLANDIA  ==");
				System.out.println("1. ¿Quién da más? (Añadir oferta)");
				System.out.println("2  Nej tak (Mostrar todas las ofertas)");
				System.out.println("3. Congelando los precios (Filtros especiales) ");
				System.out.println("4. El interrogatorio del pingüino (Buscar por oferente)");
				System.out.println("5. Aranceles para todos (Salir)");
				System.out.println("Introduce una opcion: ");

				int opcion = -1;
				boolean datosOK = false;
				while (!datosOK) {
				
						try {
							opcion = Integer.parseInt(leer.readLine());
						} catch (NumberFormatException | IOException e) {
							System.err.println("Solo puedes introducir numeros");
						}
				
					datosOK = true;
				}

				switch (opcion) {
				case 1:
					System.out.println("===  AÑADIR NUEVA OFERTA  ===");
					opcion1(ofertas);
					break;
				case 2:
					System.out.println("===  TODAS LAS OFERTAS ===");
					opcion2(ofertas);
					break;
				case 3:
					System.out.println("===  FILTROS OFERTAS RIDICULAS Y RESORT ===");
					opcion3(ofertas);
					break;
				case 4:
					System.out.println("===  BUSCAR POR NOMBRE  == ");
					opcion4(ofertas);
					break;
				case 5:
					System.out.println("¡ARANCELES PARA TODOS!");
					salir = true;
					break;
				default:
					System.out.println("Opcion no valida");
				}

			} while (!salir);
		}

	  private static void opcion1(ArrayList<Oferta> ofertas) throws IOException {
		  BufferedReader leer = new BufferedReader(new InputStreamReader(System.in));
			boolean parar = false;
			while (parar == false) {
				ofertas.add(new Oferta());
				ofertas.getLast().pedirDatos(ofertas);
				System.out.println("--- Oferta registrada con ID:"+ofertas.getLast().getId());
				System.out.println("¿Desea introducir otra oferta? (S/N)");
				char opcion1 = leer.readLine().toUpperCase().charAt(0);		
				if (opcion1 == 'N') {
					parar = true;
				}
			}
	  }
	  private static void opcion2(ArrayList<Oferta> ofertas) throws IOException {
		  for(Oferta e:ofertas) {
			  System.out.println(e.toString());
		  }
	  }
	  private static void opcion3(ArrayList<Oferta> ofertas) throws IOException {
		  System.out.println("==OFERTAS RIDICULAS==");
		  for(int i = 0; i<ofertas.size();i++) {
		  if(ofertas.get(i).ofertasBuenas()== true) {
			  System.out.println(ofertas.get(i).toString());
		  	}
		  }
		  System.out.println("==OFERTAS CON RESORT==");
		  for(int i = 0; i<ofertas.size();i++) {
		  if(ofertas.get(i).ofertasConResort()== true) {
			  System.out.println(ofertas.get(i).toString());
		  	}
		  }	  
	  }
	  private static void opcion4(ArrayList<Oferta> ofertas) throws IOException {
		  BufferedReader leer = new BufferedReader(new InputStreamReader(System.in));
		  System.out.println("Introduce el nombre del postor a buscar: ");
		  String personaBuscar = leer.readLine();
		  boolean enc = false;
		  for(int i = 0; i<ofertas.size();i++) {  
			  if(personaBuscar.equalsIgnoreCase(ofertas.get(i).getnombre())) {
				  System.out.println(ofertas.get(i).toString());
				  enc = true;
			  }
		  }
		  if (enc == false) {
			  System.out.println("Esta persona no ha hecho ninguna oferta... todavía");
		  }
	  }
}