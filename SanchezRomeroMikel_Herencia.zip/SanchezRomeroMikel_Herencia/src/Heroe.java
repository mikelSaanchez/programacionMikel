import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Heroe extends Personaje {

	private String organizacion;
	private boolean identidadSecreta;
	private String[] misiones = new String [3];

	public void pedirDatos(ArrayList<Personaje> personajes) throws IOException {
		BufferedReader leer = new BufferedReader(new InputStreamReader(System.in));
		super.pedirDatos(personajes);
		System.out.println("-------------");
		System.out.println("Organizacion:");
		organizacion = leer.readLine();
		System.out.println("¿Tiene identidad secreta? (s/n):");
		char identidad = leer.readLine().toUpperCase().charAt(0);
		if (identidad == 'S') {
			identidadSecreta = true;
		} else {
			identidadSecreta = false;
		}
		for(int i =  0; i <misiones.length;i++) {
			System.out.println("Añada Mision "+(i+1));
			misiones[i]= leer.readLine();
		}

	}

	public void mostrarDatos() {
		super.mostrarDatos();
		System.out.println("-- --- ---");
		System.out.println("Organización:" + this.organizacion);
		System.out.println("Identidad Secreta:" + this.identidadSecreta);
		for (String mostrarMiones : misiones) {
			System.out.print(mostrarMiones + ", ");
		}
	}

	public boolean isIdentidadSecreta() {
		return identidadSecreta;
	}

}
